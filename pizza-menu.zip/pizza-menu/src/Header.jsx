import React from "react";
import "./App.css";

function Header() {
  return (
    /*const style = { color: "red", fontSize: "48px", textTransform: "uppercase" };*/
    <>
      <header className="header footer">
        <h1>React Fast Pizza .Co</h1>
      </header>
    </>
  );
}

export default Header;
