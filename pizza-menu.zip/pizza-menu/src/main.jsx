import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Header from "./Header";
import Menu from "./Menu";
import Footer from "./Footer";
import Pizza from "./Pizza";
import "./App.css";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <Header className="container" />
    <Menu />
    <Footer />
  </StrictMode>
);
